import logging
from uuid import UUID

from fastapi import APIRouter, HTTPException, Response, status

from app.api.deps import ContainerDep, QueueDep, ServiceDep
from app.db.models import JobStatus
from app.schemas import (
    BatchCreate,
    BatchResponse,
    BatchResultsResponse,
    BatchSubmitResponse,
    HealthResponse,
    JobCreate,
    JobResponse,
    JobSubmitResponse,
    ResultResponse,
)
from app.services.jobs import JobService
from app.services.queue import JobQueue, QueueFullError

logger = logging.getLogger(__name__)

api_router = APIRouter(prefix="/api/v1")
health_router = APIRouter()


def _queue_full() -> HTTPException:
    return HTTPException(
        status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
        detail="The job queue is full; try again later",
        headers={"Retry-After": "5"},
    )


async def _enqueue_or_discard(
    service: JobService,
    queue: JobQueue,
    job_ids: list[str],
    batch_id: str | None = None,
) -> None:
    try:
        queue.enqueue_many(job_ids)
    except QueueFullError:
        await service.discard_jobs(job_ids, batch_id)
        raise _queue_full() from None


@api_router.post(
    "/jobs",
    response_model=JobSubmitResponse,
    status_code=status.HTTP_202_ACCEPTED,
    summary="Submit a single URL",
)
async def submit_job(
    payload: JobCreate, service: ServiceDep, queue: QueueDep
) -> JobSubmitResponse:
    if queue.free_slots == 0:
        raise _queue_full()
    job = await service.create_job(str(payload.url))
    await _enqueue_or_discard(service, queue, [job.id])
    logger.info("Accepted job %s for %s", job.id, job.url)
    return JobSubmitResponse.from_job(job)


@api_router.post(
    "/batches",
    response_model=BatchSubmitResponse,
    status_code=status.HTTP_202_ACCEPTED,
    summary="Submit multiple URLs",
)
async def submit_batch(
    payload: BatchCreate, service: ServiceDep, queue: QueueDep
) -> BatchSubmitResponse:
    free = queue.free_slots
    if free is not None and len(payload.urls) > free:
        raise _queue_full()
    batch, jobs = await service.create_batch([str(url) for url in payload.urls])
    job_ids = [job.id for job in jobs]
    await _enqueue_or_discard(service, queue, job_ids, batch.id)
    logger.info("Accepted batch %s with %d jobs", batch.id, len(jobs))
    return BatchSubmitResponse(
        batch_id=batch.id,
        status=JobStatus.PENDING,
        total=len(jobs),
        job_ids=job_ids,
        created_at=batch.created_at,
    )


@api_router.get(
    "/jobs/{job_id}", response_model=JobResponse, summary="Retrieve job status"
)
async def get_job(job_id: UUID, service: ServiceDep) -> JobResponse:
    job = await service.get_job(str(job_id))
    if job is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, detail="Job not found")
    return JobResponse.from_job(job)


@api_router.get(
    "/batches/{batch_id}", response_model=BatchResponse, summary="Retrieve batch status"
)
async def get_batch(batch_id: UUID, service: ServiceDep) -> BatchResponse:
    summary = await service.get_batch(str(batch_id))
    if summary is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, detail="Batch not found")
    return BatchResponse.from_summary(summary)


@api_router.get(
    "/batches/{batch_id}/results",
    response_model=BatchResultsResponse,
    summary="Retrieve batch results",
)
async def get_batch_results(
    batch_id: UUID, service: ServiceDep
) -> BatchResultsResponse:
    found = await service.get_batch_results(str(batch_id))
    if found is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, detail="Batch not found")
    summary, results = found
    return BatchResultsResponse(
        batch_id=summary.batch_id,
        status=summary.status,
        total=summary.total,
        completed_checks=len(results),
        results=[ResultResponse.from_result(result) for result in results],
    )


@health_router.get(
    "/health", response_model=HealthResponse, summary="Application health check"
)
async def health(
    response: Response, container: ContainerDep
) -> HealthResponse:
    database_ok = await container.database.ping()
    workers_running = container.pool.running_workers
    healthy = database_ok and workers_running > 0
    if not healthy:
        response.status_code = status.HTTP_503_SERVICE_UNAVAILABLE
    return HealthResponse(
        status="ok" if healthy else "unhealthy",
        database="ok" if database_ok else "unavailable",
        workers_running=workers_running,
        workers_busy=container.pool.busy_workers,
        queue_size=container.queue.size,
    )
