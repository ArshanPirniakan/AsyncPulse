from typing import Annotated

from fastapi import Depends, Request

from app.core.lifecycle import AppContainer
from app.services.jobs import JobService
from app.services.queue import JobQueue


def get_container(request: Request) -> AppContainer:
    return request.app.state.container


ContainerDep = Annotated[AppContainer, Depends(get_container)]


def get_service(container: ContainerDep) -> JobService:
    return container.service


def get_queue(container: ContainerDep) -> JobQueue:
    return container.queue


ServiceDep = Annotated[JobService, Depends(get_service)]
QueueDep = Annotated[JobQueue, Depends(get_queue)]
