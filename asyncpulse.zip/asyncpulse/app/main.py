from collections.abc import AsyncIterator
from contextlib import asynccontextmanager

import httpx
from fastapi import FastAPI

from app import __version__
from app.api.routes import api_router, health_router
from app.core.config import Settings
from app.core.lifecycle import AppContainer
from app.core.logging import configure_logging


def create_app(
    settings: Settings | None = None,
    transport: httpx.AsyncBaseTransport | None = None,
) -> FastAPI:
    settings = settings or Settings()
    configure_logging(settings.log_level)
    container = AppContainer(settings, transport=transport)

    @asynccontextmanager
    async def lifespan(_: FastAPI) -> AsyncIterator[None]:
        await container.start()
        try:
            yield
        finally:
            await container.stop()

    app = FastAPI(
        title="AsyncPulse",
        description="Asynchronous URL monitoring and job processing system",
        version=__version__,
        lifespan=lifespan,
    )
    app.state.container = container
    app.include_router(api_router)
    app.include_router(health_router)
    return app
