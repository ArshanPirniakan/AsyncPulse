from collections.abc import Mapping
from datetime import datetime
from typing import Annotated

from pydantic import BaseModel, Field, HttpUrl, UrlConstraints

from app.db.models import CheckResult, Job, JobStatus
from app.services.jobs import BatchSummary

MAX_BATCH_SIZE = 100
MAX_URL_LENGTH = 2048

MonitoredUrl = Annotated[
    HttpUrl, UrlConstraints(max_length=MAX_URL_LENGTH, allowed_schemes=["http", "https"])
]


class JobCreate(BaseModel):
    url: MonitoredUrl


class BatchCreate(BaseModel):
    urls: list[MonitoredUrl] = Field(min_length=1, max_length=MAX_BATCH_SIZE)


class ResultResponse(BaseModel):
    job_id: str
    url: str
    status_code: int | None
    response_time_ms: float | None
    success: bool
    error_message: str | None
    attempts: int
    checked_at: datetime

    @classmethod
    def from_result(cls, result: CheckResult) -> "ResultResponse":
        return cls(
            job_id=result.job_id,
            url=result.url,
            status_code=result.status_code,
            response_time_ms=result.response_time_ms,
            success=result.success,
            error_message=result.error_message,
            attempts=result.attempts,
            checked_at=result.checked_at,
        )


class JobSubmitResponse(BaseModel):
    job_id: str
    url: str
    status: JobStatus
    created_at: datetime

    @classmethod
    def from_job(cls, job: Job) -> "JobSubmitResponse":
        return cls(
            job_id=job.id, url=job.url, status=job.status, created_at=job.created_at
        )


class BatchSubmitResponse(BaseModel):
    batch_id: str
    status: JobStatus
    total: int
    job_ids: list[str]
    created_at: datetime


class JobResponse(BaseModel):
    job_id: str
    batch_id: str | None
    url: str
    status: JobStatus
    created_at: datetime
    updated_at: datetime
    result: ResultResponse | None

    @classmethod
    def from_job(cls, job: Job) -> "JobResponse":
        return cls(
            job_id=job.id,
            batch_id=job.batch_id,
            url=job.url,
            status=job.status,
            created_at=job.created_at,
            updated_at=job.updated_at,
            result=ResultResponse.from_result(job.result) if job.result else None,
        )


class StatusCounts(BaseModel):
    pending: int = 0
    running: int = 0
    completed: int = 0
    failed: int = 0

    @classmethod
    def from_counts(cls, counts: Mapping[JobStatus, int]) -> "StatusCounts":
        return cls(
            pending=counts.get(JobStatus.PENDING, 0),
            running=counts.get(JobStatus.RUNNING, 0),
            completed=counts.get(JobStatus.COMPLETED, 0),
            failed=counts.get(JobStatus.FAILED, 0),
        )


class BatchResponse(BaseModel):
    batch_id: str
    status: JobStatus
    total: int
    counts: StatusCounts
    created_at: datetime
    updated_at: datetime

    @classmethod
    def from_summary(cls, summary: BatchSummary) -> "BatchResponse":
        return cls(
            batch_id=summary.batch_id,
            status=summary.status,
            total=summary.total,
            counts=StatusCounts.from_counts(summary.counts),
            created_at=summary.created_at,
            updated_at=summary.updated_at,
        )


class BatchResultsResponse(BaseModel):
    batch_id: str
    status: JobStatus
    total: int
    completed_checks: int
    results: list[ResultResponse]


class HealthResponse(BaseModel):
    status: str
    database: str
    workers_running: int
    workers_busy: int
    queue_size: int
