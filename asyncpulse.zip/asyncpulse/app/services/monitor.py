import asyncio
import logging
import time
from collections.abc import Awaitable, Callable
from dataclasses import dataclass

import httpx

logger = logging.getLogger(__name__)

RETRYABLE_STATUS_CODES = frozenset({408, 425, 429})
ALLOWED_SCHEMES = frozenset({"http", "https"})


def is_retryable_status(status_code: int) -> bool:
    return status_code in RETRYABLE_STATUS_CODES or status_code >= 500


@dataclass(frozen=True, slots=True)
class CheckOutcome:
    url: str
    success: bool
    status_code: int | None
    response_time_ms: float | None
    error_message: str | None
    attempts: int

    @classmethod
    def failure(cls, url: str, message: str, attempts: int = 0) -> "CheckOutcome":
        return cls(
            url=url,
            success=False,
            status_code=None,
            response_time_ms=None,
            error_message=message,
            attempts=attempts,
        )


@dataclass(frozen=True, slots=True)
class _Attempt:
    success: bool
    retryable: bool
    status_code: int | None = None
    response_time_ms: float | None = None
    error_message: str | None = None


class UrlChecker:
    def __init__(
        self,
        client: httpx.AsyncClient,
        *,
        max_concurrency: int,
        max_retries: int,
        backoff_base: float,
        backoff_max: float,
        sleep: Callable[[float], Awaitable[None]] = asyncio.sleep,
    ) -> None:
        self._client = client
        self._semaphore = asyncio.Semaphore(max_concurrency)
        self._max_retries = max_retries
        self._backoff_base = backoff_base
        self._backoff_max = backoff_max
        self._sleep = sleep

    def backoff_delay(self, attempt: int) -> float:
        return min(self._backoff_max, self._backoff_base * 2 ** (attempt - 1))

    async def check(self, url: str) -> CheckOutcome:
        invalid_reason = self._validate(url)
        if invalid_reason is not None:
            logger.info("Rejected invalid URL %r: %s", url, invalid_reason)
            return CheckOutcome.failure(url, invalid_reason)

        max_attempts = self._max_retries + 1
        attempt_number = 0
        while True:
            attempt_number += 1
            attempt = await self._attempt(url)
            finished = (
                attempt.success or not attempt.retryable or attempt_number >= max_attempts
            )
            if finished:
                outcome = CheckOutcome(
                    url=url,
                    success=attempt.success,
                    status_code=attempt.status_code,
                    response_time_ms=attempt.response_time_ms,
                    error_message=attempt.error_message,
                    attempts=attempt_number,
                )
                logger.info(
                    "Checked %s: success=%s status=%s attempts=%d",
                    url,
                    outcome.success,
                    outcome.status_code,
                    outcome.attempts,
                )
                return outcome

            delay = self.backoff_delay(attempt_number)
            logger.warning(
                "Attempt %d/%d for %s failed (%s); retrying in %.2fs",
                attempt_number,
                max_attempts,
                url,
                attempt.error_message,
                delay,
            )
            await self._sleep(delay)

    @staticmethod
    def _validate(url: str) -> str | None:
        try:
            parsed = httpx.URL(url)
        except httpx.InvalidURL as exc:
            return f"Invalid URL: {exc}"
        if parsed.scheme not in ALLOWED_SCHEMES:
            return "Invalid URL: scheme must be http or https"
        if not parsed.host:
            return "Invalid URL: missing host"
        return None

    async def _attempt(self, url: str) -> _Attempt:
        async with self._semaphore:
            started = time.perf_counter()
            try:
                async with self._client.stream("GET", url) as response:
                    elapsed_ms = (time.perf_counter() - started) * 1000
                    status_code = response.status_code
            except httpx.TimeoutException as exc:
                return _Attempt(
                    success=False,
                    retryable=True,
                    error_message=f"Request timed out ({type(exc).__name__})",
                )
            except (httpx.UnsupportedProtocol, httpx.InvalidURL) as exc:
                return _Attempt(
                    success=False,
                    retryable=False,
                    error_message=f"Invalid URL: {exc}",
                )
            except httpx.TooManyRedirects as exc:
                return _Attempt(
                    success=False,
                    retryable=False,
                    error_message=f"Too many redirects: {exc}",
                )
            except httpx.TransportError as exc:
                return _Attempt(
                    success=False,
                    retryable=True,
                    error_message=(
                        f"Connection failed ({type(exc).__name__}): "
                        f"{exc or 'no details'}"
                    ),
                )
            except httpx.HTTPError as exc:
                return _Attempt(
                    success=False,
                    retryable=False,
                    error_message=f"HTTP error ({type(exc).__name__}): {exc}",
                )

        if status_code < 400:
            return _Attempt(
                success=True,
                retryable=False,
                status_code=status_code,
                response_time_ms=round(elapsed_ms, 2),
            )
        return _Attempt(
            success=False,
            retryable=is_retryable_status(status_code),
            status_code=status_code,
            response_time_ms=round(elapsed_ms, 2),
            error_message=f"HTTP {status_code}",
        )
