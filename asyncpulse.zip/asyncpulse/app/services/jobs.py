import logging
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from datetime import datetime

from sqlalchemy import delete, func, select, update
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker
from sqlalchemy.orm import selectinload

from app.db.models import Batch, CheckResult, Job, JobStatus, new_id, utcnow
from app.services.monitor import CheckOutcome

logger = logging.getLogger(__name__)


@dataclass(frozen=True, slots=True)
class BatchSummary:
    batch_id: str
    status: JobStatus
    total: int
    counts: Mapping[JobStatus, int]
    created_at: datetime
    updated_at: datetime


def derive_batch_status(counts: Mapping[JobStatus, int]) -> JobStatus:
    pending = counts.get(JobStatus.PENDING, 0)
    running = counts.get(JobStatus.RUNNING, 0)
    completed = counts.get(JobStatus.COMPLETED, 0)
    failed = counts.get(JobStatus.FAILED, 0)
    total = pending + running + completed + failed

    if total == 0 or pending == total:
        return JobStatus.PENDING
    if pending or running:
        return JobStatus.RUNNING
    if completed == total:
        return JobStatus.COMPLETED
    if failed == total:
        return JobStatus.FAILED
    return JobStatus.PARTIALLY_FAILED


class JobService:
    def __init__(self, session_factory: async_sessionmaker[AsyncSession]) -> None:
        self._session_factory = session_factory

    async def create_job(self, url: str) -> Job:
        async with self._session_factory() as session, session.begin():
            job = Job(id=new_id(), url=url, status=JobStatus.PENDING)
            session.add(job)
        return job

    async def create_batch(self, urls: Sequence[str]) -> tuple[Batch, list[Job]]:
        async with self._session_factory() as session, session.begin():
            batch = Batch(id=new_id())
            jobs = [
                Job(id=new_id(), batch_id=batch.id, url=url, status=JobStatus.PENDING)
                for url in urls
            ]
            session.add(batch)
            session.add_all(jobs)
        return batch, jobs

    async def discard_jobs(
        self, job_ids: Sequence[str], batch_id: str | None = None
    ) -> None:
        async with self._session_factory() as session, session.begin():
            await session.execute(delete(Job).where(Job.id.in_(job_ids)))
            if batch_id is not None:
                await session.execute(delete(Batch).where(Batch.id == batch_id))

    async def get_job(self, job_id: str) -> Job | None:
        async with self._session_factory() as session:
            result = await session.execute(
                select(Job).where(Job.id == job_id).options(selectinload(Job.result))
            )
            return result.scalar_one_or_none()

    async def get_batch(self, batch_id: str) -> BatchSummary | None:
        async with self._session_factory() as session:
            return await self._summarise_batch(session, batch_id)

    async def get_batch_results(
        self, batch_id: str
    ) -> tuple[BatchSummary, list[CheckResult]] | None:
        async with self._session_factory() as session:
            summary = await self._summarise_batch(session, batch_id)
            if summary is None:
                return None
            rows = await session.execute(
                select(CheckResult)
                .join(Job, Job.id == CheckResult.job_id)
                .where(Job.batch_id == batch_id)
                .order_by(CheckResult.checked_at, CheckResult.id)
            )
            return summary, list(rows.scalars())

    async def claim_job(self, job_id: str) -> str | None:
        async with self._session_factory() as session, session.begin():
            job = await session.get(Job, job_id)
            if job is None or job.status is not JobStatus.PENDING:
                return None
            job.status = JobStatus.RUNNING
            return job.url

    async def release_job(self, job_id: str) -> None:
        async with self._session_factory() as session, session.begin():
            await session.execute(
                update(Job)
                .where(Job.id == job_id, Job.status == JobStatus.RUNNING)
                .values(status=JobStatus.PENDING, updated_at=utcnow())
            )

    async def record_result(self, job_id: str, outcome: CheckOutcome) -> None:
        async with self._session_factory() as session, session.begin():
            job = await session.get(Job, job_id)
            if job is None:
                logger.warning("Result for unknown job %s discarded", job_id)
                return
            job.status = JobStatus.COMPLETED if outcome.success else JobStatus.FAILED
            session.add(
                CheckResult(
                    job_id=job_id,
                    url=outcome.url,
                    status_code=outcome.status_code,
                    response_time_ms=outcome.response_time_ms,
                    success=outcome.success,
                    error_message=outcome.error_message,
                    attempts=outcome.attempts,
                    checked_at=utcnow(),
                )
            )

    async def recover_unfinished(self) -> list[str]:
        async with self._session_factory() as session, session.begin():
            await session.execute(
                update(Job)
                .where(Job.status == JobStatus.RUNNING)
                .values(status=JobStatus.PENDING, updated_at=utcnow())
            )
            rows = await session.execute(
                select(Job.id)
                .where(Job.status == JobStatus.PENDING)
                .order_by(Job.created_at, Job.id)
            )
            return list(rows.scalars())

    @staticmethod
    async def _summarise_batch(
        session: AsyncSession, batch_id: str
    ) -> BatchSummary | None:
        batch = await session.get(Batch, batch_id)
        if batch is None:
            return None
        rows = await session.execute(
            select(Job.status, func.count(Job.id), func.max(Job.updated_at))
            .where(Job.batch_id == batch_id)
            .group_by(Job.status)
        )
        counts: dict[JobStatus, int] = {}
        updated_at = batch.created_at
        for status, count, last_update in rows.all():
            counts[status] = count
            if last_update is not None and last_update > updated_at:
                updated_at = last_update
        return BatchSummary(
            batch_id=batch.id,
            status=derive_batch_status(counts),
            total=sum(counts.values()),
            counts=counts,
            created_at=batch.created_at,
            updated_at=updated_at,
        )
