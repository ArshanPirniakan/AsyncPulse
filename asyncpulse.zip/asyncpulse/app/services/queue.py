import asyncio
from collections.abc import Sequence


class QueueFullError(Exception):
    pass


class JobQueue:
    def __init__(self, maxsize: int = 0) -> None:
        self._queue: asyncio.Queue[str] = asyncio.Queue(maxsize=maxsize)

    @property
    def maxsize(self) -> int:
        return self._queue.maxsize

    @property
    def size(self) -> int:
        return self._queue.qsize()

    @property
    def free_slots(self) -> int | None:
        if self._queue.maxsize == 0:
            return None
        return self._queue.maxsize - self._queue.qsize()

    def enqueue(self, job_id: str) -> None:
        self.enqueue_many([job_id])

    def enqueue_many(self, job_ids: Sequence[str]) -> None:
        free = self.free_slots
        if free is not None and len(job_ids) > free:
            raise QueueFullError(
                f"Queue has {free} free slots but {len(job_ids)} are required"
            )
        for job_id in job_ids:
            self._queue.put_nowait(job_id)

    async def put(self, job_id: str) -> None:
        await self._queue.put(job_id)

    async def get(self) -> str:
        return await self._queue.get()

    def task_done(self) -> None:
        self._queue.task_done()

    async def join(self) -> None:
        await self._queue.join()
