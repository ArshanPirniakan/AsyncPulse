import asyncio
import logging

from app.services.jobs import JobService
from app.services.monitor import CheckOutcome, UrlChecker
from app.services.queue import JobQueue

logger = logging.getLogger(__name__)


class WorkerPool:
    def __init__(
        self,
        queue: JobQueue,
        service: JobService,
        checker: UrlChecker,
        worker_count: int,
    ) -> None:
        self._queue = queue
        self._service = service
        self._checker = checker
        self._worker_count = worker_count
        self._tasks: list[asyncio.Task[None]] = []
        self._busy: set[int] = set()
        self._stopping = False

    @property
    def worker_count(self) -> int:
        return self._worker_count

    @property
    def running_workers(self) -> int:
        return sum(1 for task in self._tasks if not task.done())

    @property
    def busy_workers(self) -> int:
        return len(self._busy)

    @property
    def is_running(self) -> bool:
        return self.running_workers > 0

    def start(self) -> None:
        if self._tasks:
            raise RuntimeError("Worker pool is already started")
        self._stopping = False
        self._tasks = [
            asyncio.create_task(self._run(index), name=f"asyncpulse-worker-{index}")
            for index in range(self._worker_count)
        ]
        logger.info("Started %d workers", self._worker_count)

    async def stop(self, timeout: float) -> None:
        if not self._tasks:
            return
        logger.info("Stopping workers (timeout %.1fs)", timeout)
        self._stopping = True

        for index, task in enumerate(self._tasks):
            if index not in self._busy:
                task.cancel()

        remaining = [task for task in self._tasks if not task.done()]
        if remaining:
            _, timed_out = await asyncio.wait(remaining, timeout=timeout)
            if timed_out:
                logger.warning(
                    "%d workers did not finish in time; cancelling", len(timed_out)
                )
                for task in timed_out:
                    task.cancel()

        await asyncio.gather(*self._tasks, return_exceptions=True)
        self._tasks = []
        self._busy.clear()
        logger.info("Workers stopped")

    async def _run(self, index: int) -> None:
        logger.debug("Worker %d started", index)
        while not self._stopping:
            job_id = await self._queue.get()
            self._busy.add(index)
            try:
                await self._process(job_id)
            except asyncio.CancelledError:
                raise
            except Exception:
                logger.exception("Worker %d failed while processing job %s", index, job_id)
            finally:
                self._busy.discard(index)
                self._queue.task_done()
        logger.debug("Worker %d exiting", index)

    async def _process(self, job_id: str) -> None:
        url = await self._service.claim_job(job_id)
        if url is None:
            logger.debug("Job %s is not pending; skipping", job_id)
            return

        try:
            outcome = await self._checker.check(url)
        except asyncio.CancelledError:
            logger.info("Job %s interrupted; returning it to PENDING", job_id)
            await asyncio.shield(self._service.release_job(job_id))
            raise
        except Exception as exc:
            logger.exception("Unexpected error checking %s", url)
            outcome = CheckOutcome.failure(
                url, f"Unexpected error ({type(exc).__name__}): {exc}", attempts=1
            )

        await self._service.record_result(job_id, outcome)
