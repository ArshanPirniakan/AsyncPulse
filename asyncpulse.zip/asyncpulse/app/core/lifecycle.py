import asyncio
import contextlib
import logging

import httpx

from app.core.config import Settings
from app.db.session import Database
from app.services.jobs import JobService
from app.services.monitor import UrlChecker
from app.services.queue import JobQueue
from app.services.workers import WorkerPool

logger = logging.getLogger(__name__)


class AppContainer:
    def __init__(
        self,
        settings: Settings,
        transport: httpx.AsyncBaseTransport | None = None,
    ) -> None:
        self.settings = settings
        self.database = Database(settings.database_url)
        self.service = JobService(self.database.session_factory)
        self.queue = JobQueue(maxsize=settings.queue_maxsize)
        self.client = httpx.AsyncClient(
            timeout=httpx.Timeout(settings.request_timeout),
            follow_redirects=True,
            headers={"User-Agent": settings.user_agent},
            transport=transport,
        )
        self.checker = UrlChecker(
            self.client,
            max_concurrency=settings.max_concurrency,
            max_retries=settings.max_retries,
            backoff_base=settings.backoff_base,
            backoff_max=settings.backoff_max,
        )
        self.pool = WorkerPool(
            self.queue, self.service, self.checker, settings.worker_count
        )
        self.recovery_task: asyncio.Task[None] | None = None

    async def start(self) -> None:
        await self.database.create_all()
        unfinished = await self.service.recover_unfinished()
        self.pool.start()
        if unfinished:
            logger.info("Re-queueing %d unfinished jobs", len(unfinished))
            self.recovery_task = asyncio.create_task(
                self._requeue(unfinished), name="asyncpulse-recovery"
            )
        logger.info("AsyncPulse started")

    async def stop(self) -> None:
        if self.recovery_task is not None:
            self.recovery_task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await self.recovery_task
            self.recovery_task = None
        await self.pool.stop(self.settings.shutdown_timeout)
        await self.client.aclose()
        await self.database.dispose()
        logger.info("AsyncPulse stopped")

    async def _requeue(self, job_ids: list[str]) -> None:
        for job_id in job_ids:
            await self.queue.put(job_id)
