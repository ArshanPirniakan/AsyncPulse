from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_prefix="ASYNCPULSE_",
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    database_url: str = "sqlite+aiosqlite:///./asyncpulse.db"
    worker_count: int = Field(default=4, ge=1, le=200)
    max_concurrency: int = Field(default=10, ge=1)
    request_timeout: float = Field(default=10.0, gt=0)
    max_retries: int = Field(default=3, ge=0, le=20)
    backoff_base: float = Field(default=0.5, ge=0)
    backoff_max: float = Field(default=30.0, ge=0)
    queue_maxsize: int = Field(default=1000, ge=0)
    shutdown_timeout: float = Field(default=10.0, ge=0)
    user_agent: str = "AsyncPulse/1.0"
    log_level: str = "INFO"
