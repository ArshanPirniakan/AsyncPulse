import logging

LOG_FORMAT = "%(asctime)s %(levelname)-8s %(name)s: %(message)s"


def configure_logging(level: str = "INFO") -> None:
    numeric_level = logging.getLevelNamesMapping().get(level.upper(), logging.INFO)
    root = logging.getLogger()
    if not root.handlers:
        logging.basicConfig(level=numeric_level, format=LOG_FORMAT)
    root.setLevel(numeric_level)
    logging.getLogger("httpx").setLevel(max(numeric_level, logging.WARNING))
    logging.getLogger("httpcore").setLevel(max(numeric_level, logging.WARNING))
