import asyncio

import pytest

from app.services.queue import JobQueue, QueueFullError


async def test_fifo_order():
    queue = JobQueue()
    queue.enqueue_many(["a", "b", "c"])

    assert queue.size == 3
    assert [await queue.get() for _ in range(3)] == ["a", "b", "c"]
    assert queue.size == 0


async def test_unbounded_queue_reports_no_free_slot_limit():
    queue = JobQueue(maxsize=0)

    assert queue.free_slots is None
    queue.enqueue_many([str(i) for i in range(500)])
    assert queue.size == 500


async def test_bounded_queue_rejects_when_full():
    queue = JobQueue(maxsize=2)
    queue.enqueue("a")
    queue.enqueue("b")

    assert queue.free_slots == 0
    with pytest.raises(QueueFullError):
        queue.enqueue("c")
    assert queue.size == 2


async def test_enqueue_many_is_all_or_nothing():
    queue = JobQueue(maxsize=3)
    queue.enqueue("a")

    with pytest.raises(QueueFullError):
        queue.enqueue_many(["b", "c", "d"])

    assert queue.size == 1
    assert queue.free_slots == 2


async def test_get_waits_for_item():
    queue = JobQueue()
    getter = asyncio.create_task(queue.get())
    await asyncio.sleep(0.01)
    assert not getter.done()

    queue.enqueue("late")

    assert await asyncio.wait_for(getter, timeout=1) == "late"


async def test_join_completes_after_task_done():
    queue = JobQueue()
    queue.enqueue_many(["a", "b"])

    async def consume() -> None:
        for _ in range(2):
            await queue.get()
            queue.task_done()

    consumer = asyncio.create_task(consume())
    await asyncio.wait_for(queue.join(), timeout=1)
    await consumer


async def test_async_put_blocks_until_space_available():
    queue = JobQueue(maxsize=1)
    queue.enqueue("a")

    putter = asyncio.create_task(queue.put("b"))
    await asyncio.sleep(0.01)
    assert not putter.done()

    assert await queue.get() == "a"
    await asyncio.wait_for(putter, timeout=1)
    assert await queue.get() == "b"
