import asyncio

import httpx
import pytest

from app.services.monitor import UrlChecker, is_retryable_status


def build_checker(handler, *, max_concurrency=5, max_retries=2, base=0.5, cap=30.0):
    sleeps: list[float] = []

    async def fake_sleep(delay: float) -> None:
        sleeps.append(delay)

    client = httpx.AsyncClient(transport=httpx.MockTransport(handler), follow_redirects=True)
    checker = UrlChecker(
        client,
        max_concurrency=max_concurrency,
        max_retries=max_retries,
        backoff_base=base,
        backoff_max=cap,
        sleep=fake_sleep,
    )
    return checker, client, sleeps


async def test_successful_request_records_details():
    checker, client, sleeps = build_checker(lambda r: httpx.Response(200))
    async with client:
        outcome = await checker.check("https://example.com/")

    assert outcome.success is True
    assert outcome.status_code == 200
    assert outcome.attempts == 1
    assert outcome.error_message is None
    assert outcome.response_time_ms is not None and outcome.response_time_ms >= 0
    assert sleeps == []


async def test_redirects_are_followed():
    def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path == "/old":
            return httpx.Response(301, headers={"Location": "https://example.com/new"})
        return httpx.Response(200)

    checker, client, _ = build_checker(handler)
    async with client:
        outcome = await checker.check("https://example.com/old")

    assert outcome.success is True
    assert outcome.status_code == 200


async def test_client_error_is_failure_without_retry():
    calls = 0

    def handler(request: httpx.Request) -> httpx.Response:
        nonlocal calls
        calls += 1
        return httpx.Response(404)

    checker, client, sleeps = build_checker(handler)
    async with client:
        outcome = await checker.check("https://example.com/missing")

    assert outcome.success is False
    assert outcome.status_code == 404
    assert outcome.error_message == "HTTP 404"
    assert outcome.attempts == 1
    assert calls == 1
    assert sleeps == []


async def test_server_error_is_retried_until_success():
    responses = iter([503, 502, 200])

    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(next(responses))

    checker, client, sleeps = build_checker(handler, max_retries=3)
    async with client:
        outcome = await checker.check("https://example.com/")

    assert outcome.success is True
    assert outcome.attempts == 3
    assert outcome.status_code == 200
    assert sleeps == [0.5, 1.0]


async def test_retries_are_exhausted():
    calls = 0

    def handler(request: httpx.Request) -> httpx.Response:
        nonlocal calls
        calls += 1
        return httpx.Response(500)

    checker, client, sleeps = build_checker(handler, max_retries=2)
    async with client:
        outcome = await checker.check("https://example.com/")

    assert outcome.success is False
    assert outcome.status_code == 500
    assert outcome.attempts == 3
    assert calls == 3
    assert len(sleeps) == 2


async def test_zero_retries_means_single_attempt():
    checker, client, sleeps = build_checker(lambda r: httpx.Response(500), max_retries=0)
    async with client:
        outcome = await checker.check("https://example.com/")

    assert outcome.attempts == 1
    assert sleeps == []


async def test_exponential_backoff_delays_and_cap():
    checker, client, sleeps = build_checker(
        lambda r: httpx.Response(503), max_retries=5, base=1.0, cap=5.0
    )
    async with client:
        outcome = await checker.check("https://example.com/")

    assert outcome.attempts == 6
    assert sleeps == [1.0, 2.0, 4.0, 5.0, 5.0]


async def test_timeout_is_retried_and_reported():
    def handler(request: httpx.Request) -> httpx.Response:
        raise httpx.ReadTimeout("too slow", request=request)

    checker, client, sleeps = build_checker(handler, max_retries=1)
    async with client:
        outcome = await checker.check("https://example.com/")

    assert outcome.success is False
    assert outcome.status_code is None
    assert outcome.response_time_ms is None
    assert "timed out" in outcome.error_message
    assert outcome.attempts == 2
    assert len(sleeps) == 1


async def test_real_client_timeout_against_local_silent_server():
    async def silent(reader: asyncio.StreamReader, writer: asyncio.StreamWriter) -> None:
        try:
            await asyncio.sleep(5)
        finally:
            writer.close()

    server = await asyncio.start_server(silent, "127.0.0.1", 0)
    port = server.sockets[0].getsockname()[1]
    sleeps: list[float] = []

    async def fake_sleep(delay: float) -> None:
        sleeps.append(delay)

    try:
        async with httpx.AsyncClient(timeout=httpx.Timeout(0.1)) as client:
            checker = UrlChecker(
                client,
                max_concurrency=1,
                max_retries=1,
                backoff_base=0.1,
                backoff_max=1,
                sleep=fake_sleep,
            )
            outcome = await asyncio.wait_for(
                checker.check(f"http://127.0.0.1:{port}/"), timeout=3
            )
    finally:
        server.close()

    assert outcome.success is False
    assert outcome.attempts == 2
    assert "timed out" in outcome.error_message
    assert sleeps == [0.1]


async def test_connection_failure_is_retryable():
    calls = 0

    def handler(request: httpx.Request) -> httpx.Response:
        nonlocal calls
        calls += 1
        if calls < 3:
            raise httpx.ConnectError("connection refused", request=request)
        return httpx.Response(200)

    checker, client, sleeps = build_checker(handler, max_retries=3)
    async with client:
        outcome = await checker.check("https://example.com/")

    assert outcome.success is True
    assert outcome.attempts == 3
    assert len(sleeps) == 2


async def test_connection_failure_reports_error_when_exhausted():
    def handler(request: httpx.Request) -> httpx.Response:
        raise httpx.ConnectError("connection refused", request=request)

    checker, client, _ = build_checker(handler, max_retries=1)
    async with client:
        outcome = await checker.check("https://example.com/")

    assert outcome.success is False
    assert "Connection failed" in outcome.error_message
    assert "connection refused" in outcome.error_message
    assert outcome.attempts == 2


async def test_too_many_redirects_is_not_retried():
    def handler(request: httpx.Request) -> httpx.Response:
        raise httpx.TooManyRedirects("loop", request=request)

    checker, client, sleeps = build_checker(handler)
    async with client:
        outcome = await checker.check("https://example.com/")

    assert outcome.success is False
    assert outcome.attempts == 1
    assert sleeps == []
    assert "redirect" in outcome.error_message.lower()


@pytest.mark.parametrize(
    "url",
    ["not a url", "ftp://example.com/file", "example.com", "http://", "", "file:///etc/passwd"],
)
async def test_invalid_urls_fail_without_network_calls(url):
    calls = 0

    def handler(request: httpx.Request) -> httpx.Response:
        nonlocal calls
        calls += 1
        return httpx.Response(200)

    checker, client, sleeps = build_checker(handler)
    async with client:
        outcome = await checker.check(url)

    assert outcome.success is False
    assert outcome.attempts == 0
    assert outcome.error_message.startswith("Invalid URL")
    assert calls == 0
    assert sleeps == []


@pytest.mark.parametrize(
    ("status_code", "expected"),
    [(200, False), (301, False), (400, False), (404, False), (408, True), (429, True), (500, True), (503, True)],
)
def test_retryable_status_codes(status_code, expected):
    assert is_retryable_status(status_code) is expected


async def test_concurrent_checks_run_in_parallel():
    active = 0
    peak = 0

    async def handler(request: httpx.Request) -> httpx.Response:
        nonlocal active, peak
        active += 1
        peak = max(peak, active)
        await asyncio.sleep(0.05)
        active -= 1
        return httpx.Response(200)

    checker, client, _ = build_checker(handler, max_concurrency=10)
    async with client:
        outcomes = await asyncio.gather(
            *(checker.check(f"https://example.com/{i}") for i in range(8))
        )

    assert all(outcome.success for outcome in outcomes)
    assert peak == 8


async def test_semaphore_limits_concurrency():
    active = 0
    peak = 0

    async def handler(request: httpx.Request) -> httpx.Response:
        nonlocal active, peak
        active += 1
        peak = max(peak, active)
        await asyncio.sleep(0.02)
        active -= 1
        return httpx.Response(200)

    checker, client, _ = build_checker(handler, max_concurrency=3)
    async with client:
        outcomes = await asyncio.gather(
            *(checker.check(f"https://example.com/{i}") for i in range(15))
        )

    assert len(outcomes) == 15
    assert all(outcome.success for outcome in outcomes)
    assert peak == 3


async def test_semaphore_is_released_after_failures():
    def handler(request: httpx.Request) -> httpx.Response:
        raise httpx.ConnectError("down", request=request)

    checker, client, _ = build_checker(handler, max_concurrency=1, max_retries=2)
    async with client:
        outcomes = await asyncio.wait_for(
            asyncio.gather(*(checker.check(f"https://example.com/{i}") for i in range(4))),
            timeout=2,
        )

    assert all(not outcome.success for outcome in outcomes)
