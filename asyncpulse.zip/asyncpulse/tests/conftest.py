import asyncio
import time
from collections.abc import AsyncIterator, Callable
from contextlib import asynccontextmanager
from pathlib import Path

import httpx
import pytest

from app.core.config import Settings
from app.db.session import Database
from app.main import create_app
from app.services.jobs import JobService


def make_settings(tmp_path: Path, **overrides: object) -> Settings:
    values: dict[str, object] = {
        "database_url": f"sqlite+aiosqlite:///{tmp_path / 'test.db'}",
        "worker_count": 2,
        "max_concurrency": 5,
        "request_timeout": 1.0,
        "max_retries": 2,
        "backoff_base": 0.0,
        "backoff_max": 0.0,
        "shutdown_timeout": 2.0,
        "log_level": "WARNING",
    }
    values.update(overrides)
    return Settings(_env_file=None, **values)


async def wait_until(
    predicate: Callable[[], object], timeout: float = 5.0, interval: float = 0.01
) -> None:
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        result = predicate()
        if asyncio.iscoroutine(result):
            result = await result
        if result:
            return
        await asyncio.sleep(interval)
    raise AssertionError("Condition was not met before the timeout")


@pytest.fixture
def settings(tmp_path: Path) -> Settings:
    return make_settings(tmp_path)


@pytest.fixture
async def database(settings: Settings) -> AsyncIterator[Database]:
    db = Database(settings.database_url)
    await db.create_all()
    yield db
    await db.dispose()


@pytest.fixture
def service(database: Database) -> JobService:
    return JobService(database.session_factory)


@pytest.fixture
def app_factory(tmp_path: Path):
    @asynccontextmanager
    async def build(handler: Callable[[httpx.Request], object], **overrides: object):
        settings = make_settings(tmp_path, **overrides)
        app = create_app(settings, transport=httpx.MockTransport(handler))
        async with app.router.lifespan_context(app):
            async with httpx.AsyncClient(
                transport=httpx.ASGITransport(app=app), base_url="http://testserver"
            ) as client:
                yield app, client

    return build


def ok_handler(request: httpx.Request) -> httpx.Response:
    return httpx.Response(200, text="ok")
