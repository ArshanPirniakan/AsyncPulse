import asyncio
from uuid import uuid4

import httpx
import pytest

from app.db.session import Database
from app.main import create_app
from app.services.jobs import JobService
from tests.conftest import make_settings, ok_handler, wait_until

TERMINAL = {"COMPLETED", "FAILED", "PARTIALLY_FAILED"}


async def wait_for_batch(client: httpx.AsyncClient, batch_id: str, timeout: float = 5.0) -> dict:
    async def done() -> bool:
        body = (await client.get(f"/api/v1/batches/{batch_id}")).json()
        return body["status"] in TERMINAL

    await wait_until(done, timeout=timeout)
    return (await client.get(f"/api/v1/batches/{batch_id}")).json()


async def wait_for_job(client: httpx.AsyncClient, job_id: str, timeout: float = 5.0) -> dict:
    async def done() -> bool:
        body = (await client.get(f"/api/v1/jobs/{job_id}")).json()
        return body["status"] in TERMINAL

    await wait_until(done, timeout=timeout)
    return (await client.get(f"/api/v1/jobs/{job_id}")).json()


async def test_health_endpoint(app_factory):
    async with app_factory(ok_handler) as (_, client):
        response = await client.get("/health")

    assert response.status_code == 200
    body = response.json()
    assert body["status"] == "ok"
    assert body["database"] == "ok"
    assert body["workers_running"] == 2
    assert body["queue_size"] == 0


async def test_submit_single_job_returns_immediately_and_completes(app_factory):
    release = asyncio.Event()

    async def handler(request: httpx.Request) -> httpx.Response:
        await release.wait()
        return httpx.Response(200)

    async with app_factory(handler) as (_, client):
        response = await client.post("/api/v1/jobs", json={"url": "https://example.com"})
        assert response.status_code == 202
        body = response.json()
        assert body["status"] == "PENDING"
        assert body["url"] == "https://example.com/"
        job_id = body["job_id"]

        running = (await client.get(f"/api/v1/jobs/{job_id}")).json()
        assert running["status"] in {"PENDING", "RUNNING"}
        assert running["result"] is None

        release.set()
        finished = await wait_for_job(client, job_id)

    assert finished["status"] == "COMPLETED"
    assert finished["batch_id"] is None
    assert finished["result"]["status_code"] == 200
    assert finished["result"]["success"] is True
    assert finished["result"]["attempts"] == 1
    assert finished["result"]["error_message"] is None
    assert finished["result"]["response_time_ms"] >= 0
    assert finished["result"]["checked_at"]


async def test_failed_job_reports_error(app_factory):
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(404)

    async with app_factory(handler) as (_, client):
        job_id = (await client.post("/api/v1/jobs", json={"url": "https://example.com/x"})).json()["job_id"]
        finished = await wait_for_job(client, job_id)

    assert finished["status"] == "FAILED"
    assert finished["result"]["status_code"] == 404
    assert finished["result"]["error_message"] == "HTTP 404"


async def test_retries_are_visible_in_result(app_factory):
    responses = iter([503, 503, 200])

    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(next(responses))

    async with app_factory(handler, max_retries=3) as (_, client):
        job_id = (await client.post("/api/v1/jobs", json={"url": "https://flaky.test/"})).json()["job_id"]
        finished = await wait_for_job(client, job_id)

    assert finished["status"] == "COMPLETED"
    assert finished["result"]["attempts"] == 3


@pytest.mark.parametrize(
    "payload",
    [
        {},
        {"url": ""},
        {"url": "not-a-url"},
        {"url": "ftp://example.com/file"},
        {"url": "javascript:alert(1)"},
        {"url": 123},
        {"url": "https://example.com/" + "a" * 3000},
    ],
)
async def test_submit_job_rejects_invalid_payloads(app_factory, payload):
    async with app_factory(ok_handler) as (_, client):
        response = await client.post("/api/v1/jobs", json=payload)

    assert response.status_code == 422


async def test_submit_batch_and_fetch_results(app_factory):
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200)

    urls = [f"https://site{i}.test/" for i in range(5)]
    async with app_factory(handler) as (_, client):
        response = await client.post("/api/v1/batches", json={"urls": urls})
        assert response.status_code == 202
        body = response.json()
        assert body["total"] == 5
        assert body["status"] == "PENDING"
        assert len(set(body["job_ids"])) == 5
        batch_id = body["batch_id"]

        summary = await wait_for_batch(client, batch_id)
        results = await client.get(f"/api/v1/batches/{batch_id}/results")
        job = (await client.get(f"/api/v1/jobs/{body['job_ids'][0]}")).json()

    assert summary["status"] == "COMPLETED"
    assert summary["total"] == 5
    assert summary["counts"] == {"pending": 0, "running": 0, "completed": 5, "failed": 0}
    assert results.status_code == 200
    results_body = results.json()
    assert results_body["status"] == "COMPLETED"
    assert results_body["completed_checks"] == 5
    assert sorted(item["url"] for item in results_body["results"]) == sorted(urls)
    assert all(item["success"] for item in results_body["results"])
    assert job["batch_id"] == batch_id


async def test_batch_with_mixed_outcomes_is_partially_failed(app_factory):
    def handler(request: httpx.Request) -> httpx.Response:
        if request.url.host == "bad.test":
            return httpx.Response(404)
        if request.url.host == "down.test":
            raise httpx.ConnectError("refused", request=request)
        return httpx.Response(200)

    urls = ["https://good.test/", "https://bad.test/", "https://down.test/"]
    async with app_factory(handler) as (_, client):
        batch_id = (await client.post("/api/v1/batches", json={"urls": urls})).json()["batch_id"]
        summary = await wait_for_batch(client, batch_id)
        results = (await client.get(f"/api/v1/batches/{batch_id}/results")).json()

    assert summary["status"] == "PARTIALLY_FAILED"
    assert summary["counts"]["completed"] == 1
    assert summary["counts"]["failed"] == 2
    by_url = {item["url"]: item for item in results["results"]}
    assert by_url["https://bad.test/"]["status_code"] == 404
    assert by_url["https://down.test/"]["status_code"] is None
    assert "Connection failed" in by_url["https://down.test/"]["error_message"]
    assert by_url["https://down.test/"]["attempts"] == 3


async def test_batch_where_everything_fails_is_failed(app_factory):
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(404)

    async with app_factory(handler) as (_, client):
        batch_id = (
            await client.post("/api/v1/batches", json={"urls": ["https://a.test/", "https://b.test/"]})
        ).json()["batch_id"]
        summary = await wait_for_batch(client, batch_id)

    assert summary["status"] == "FAILED"


async def test_batch_results_before_completion_are_partial(app_factory):
    release = asyncio.Event()

    async def handler(request: httpx.Request) -> httpx.Response:
        await release.wait()
        return httpx.Response(200)

    async with app_factory(handler) as (_, client):
        batch_id = (await client.post("/api/v1/batches", json={"urls": ["https://a.test/"]})).json()["batch_id"]
        await asyncio.sleep(0.05)
        early = (await client.get(f"/api/v1/batches/{batch_id}/results")).json()
        release.set()
        await wait_for_batch(client, batch_id)

    assert early["status"] == "RUNNING"
    assert early["completed_checks"] == 0
    assert early["results"] == []


@pytest.mark.parametrize(
    "payload",
    [
        {},
        {"urls": []},
        {"urls": "https://example.com"},
        {"urls": ["https://example.com", "nope"]},
        {"urls": ["https://example.com"] * 101},
    ],
)
async def test_submit_batch_rejects_invalid_payloads(app_factory, payload):
    async with app_factory(ok_handler) as (_, client):
        response = await client.post("/api/v1/batches", json=payload)

    assert response.status_code == 422


async def test_unknown_resources_return_404(app_factory):
    missing = str(uuid4())
    async with app_factory(ok_handler) as (_, client):
        job = await client.get(f"/api/v1/jobs/{missing}")
        batch = await client.get(f"/api/v1/batches/{missing}")
        results = await client.get(f"/api/v1/batches/{missing}/results")

    assert job.status_code == 404
    assert batch.status_code == 404
    assert results.status_code == 404


async def test_malformed_ids_return_422(app_factory):
    async with app_factory(ok_handler) as (_, client):
        response = await client.get("/api/v1/jobs/not-a-uuid")

    assert response.status_code == 422


async def test_queue_full_returns_503_and_leaves_no_records(app_factory):
    release = asyncio.Event()

    async def handler(request: httpx.Request) -> httpx.Response:
        await release.wait()
        return httpx.Response(200)

    async with app_factory(handler, worker_count=1, queue_maxsize=2) as (app, client):
        first = await client.post("/api/v1/jobs", json={"url": "https://one.test/"})
        assert first.status_code == 202
        await wait_until(lambda: app.state.container.pool.busy_workers == 1)

        await client.post("/api/v1/batches", json={"urls": ["https://two.test/", "https://three.test/"]})
        too_many = await client.post("/api/v1/batches", json={"urls": ["https://four.test/"]})
        single = await client.post("/api/v1/jobs", json={"url": "https://five.test/"})

        assert too_many.status_code == 503
        assert single.status_code == 503
        assert too_many.headers["retry-after"]
        assert app.state.container.queue.size == 2
        release.set()


async def test_concurrent_submissions_are_all_processed(app_factory):
    async with app_factory(ok_handler, worker_count=4) as (_, client):
        responses = await asyncio.gather(
            *(client.post("/api/v1/jobs", json={"url": f"https://c{i}.test/"}) for i in range(20))
        )
        job_ids = [response.json()["job_id"] for response in responses]
        finished = await asyncio.gather(*(wait_for_job(client, job_id) for job_id in job_ids))

    assert len(set(job_ids)) == 20
    assert all(job["status"] == "COMPLETED" for job in finished)


async def test_application_recovers_unfinished_jobs_after_restart(tmp_path):
    settings = make_settings(tmp_path)
    database = Database(settings.database_url)
    await database.create_all()
    service = JobService(database.session_factory)
    pending = await service.create_job("https://pending.test/")
    interrupted = await service.create_job("https://interrupted.test/")
    await service.claim_job(interrupted.id)
    await database.dispose()

    app = create_app(settings, transport=httpx.MockTransport(ok_handler))
    async with app.router.lifespan_context(app):
        async with httpx.AsyncClient(
            transport=httpx.ASGITransport(app=app), base_url="http://testserver"
        ) as client:
            first_job = await wait_for_job(client, pending.id)
            second_job = await wait_for_job(client, interrupted.id)

    assert first_job["status"] == "COMPLETED"
    assert second_job["status"] == "COMPLETED"


async def test_results_persist_across_app_restarts(tmp_path):
    settings = make_settings(tmp_path)

    first_app = create_app(settings, transport=httpx.MockTransport(ok_handler))
    async with first_app.router.lifespan_context(first_app):
        async with httpx.AsyncClient(
            transport=httpx.ASGITransport(app=first_app), base_url="http://testserver"
        ) as client:
            batch_id = (
                await client.post("/api/v1/batches", json={"urls": ["https://keep.test/"]})
            ).json()["batch_id"]
            await wait_for_batch(client, batch_id)

    second_app = create_app(settings, transport=httpx.MockTransport(ok_handler))
    async with second_app.router.lifespan_context(second_app):
        async with httpx.AsyncClient(
            transport=httpx.ASGITransport(app=second_app), base_url="http://testserver"
        ) as client:
            results = (await client.get(f"/api/v1/batches/{batch_id}/results")).json()

    assert results["status"] == "COMPLETED"
    assert results["results"][0]["url"] == "https://keep.test/"


async def test_lifespan_shuts_workers_down(tmp_path):
    app = create_app(make_settings(tmp_path), transport=httpx.MockTransport(ok_handler))
    container = app.state.container

    async with app.router.lifespan_context(app):
        await wait_until(lambda: container.pool.running_workers == 2)

    assert container.pool.running_workers == 0
    assert container.client.is_closed


async def test_shutdown_during_inflight_work_returns_jobs_to_pending(tmp_path):
    started = asyncio.Event()

    async def hang(request: httpx.Request) -> httpx.Response:
        started.set()
        await asyncio.sleep(30)
        return httpx.Response(200)

    settings = make_settings(tmp_path, shutdown_timeout=0.05, worker_count=1)
    app = create_app(settings, transport=httpx.MockTransport(hang))
    async with app.router.lifespan_context(app):
        async with httpx.AsyncClient(
            transport=httpx.ASGITransport(app=app), base_url="http://testserver"
        ) as client:
            job_id = (await client.post("/api/v1/jobs", json={"url": "https://hang.test/"})).json()["job_id"]
            await asyncio.wait_for(started.wait(), timeout=2)

    restarted = create_app(settings, transport=httpx.MockTransport(ok_handler))
    async with restarted.router.lifespan_context(restarted):
        async with httpx.AsyncClient(
            transport=httpx.ASGITransport(app=restarted), base_url="http://testserver"
        ) as client:
            finished = await wait_for_job(client, job_id)

    assert finished["status"] == "COMPLETED"
