import asyncio

from app.db.models import JobStatus
from app.services.jobs import JobService
from app.services.monitor import CheckOutcome
from app.services.queue import JobQueue
from app.services.workers import WorkerPool
from tests.conftest import wait_until


class StubChecker:
    def __init__(self, delay: float = 0.0, fail_urls: frozenset[str] = frozenset()) -> None:
        self.delay = delay
        self.fail_urls = fail_urls
        self.active = 0
        self.peak = 0
        self.seen: list[str] = []
        self.release = asyncio.Event()
        self.started = asyncio.Event()

    async def check(self, url: str) -> CheckOutcome:
        self.active += 1
        self.peak = max(self.peak, self.active)
        self.seen.append(url)
        self.started.set()
        try:
            await asyncio.sleep(self.delay)
            if url in self.fail_urls:
                return CheckOutcome(url, False, 500, 1.0, "HTTP 500", 3)
            return CheckOutcome(url, True, 200, 1.0, None, 1)
        finally:
            self.active -= 1


class BlockingChecker(StubChecker):
    async def check(self, url: str) -> CheckOutcome:
        self.started.set()
        await self.release.wait()
        return CheckOutcome(url, True, 200, 1.0, None, 1)


class ExplodingChecker:
    async def check(self, url: str) -> CheckOutcome:
        if "boom" in url:
            raise RuntimeError("kaboom")
        return CheckOutcome(url, True, 200, 1.0, None, 1)


async def batch_status(service: JobService, batch_id: str) -> JobStatus:
    return (await service.get_batch(batch_id)).status


async def test_workers_process_queued_jobs(service: JobService):
    queue = JobQueue()
    pool = WorkerPool(queue, service, StubChecker(), worker_count=3)
    batch, jobs = await service.create_batch([f"https://{i}.test/" for i in range(6)])
    queue.enqueue_many([job.id for job in jobs])

    pool.start()
    try:
        await asyncio.wait_for(queue.join(), timeout=5)
    finally:
        await pool.stop(timeout=2)

    summary = await service.get_batch(batch.id)
    assert summary.status is JobStatus.COMPLETED
    assert summary.counts == {JobStatus.COMPLETED: 6}


async def test_mixed_results_produce_partially_failed_batch(service: JobService):
    queue = JobQueue()
    checker = StubChecker(fail_urls=frozenset({"https://bad.test/"}))
    pool = WorkerPool(queue, service, checker, worker_count=2)
    batch, jobs = await service.create_batch(["https://good.test/", "https://bad.test/"])
    queue.enqueue_many([job.id for job in jobs])

    pool.start()
    try:
        await asyncio.wait_for(queue.join(), timeout=5)
    finally:
        await pool.stop(timeout=2)

    assert await batch_status(service, batch.id) is JobStatus.PARTIALLY_FAILED


async def test_multiple_workers_run_jobs_concurrently(service: JobService):
    queue = JobQueue()
    checker = StubChecker(delay=0.05)
    pool = WorkerPool(queue, service, checker, worker_count=4)
    _, jobs = await service.create_batch([f"https://{i}.test/" for i in range(8)])
    queue.enqueue_many([job.id for job in jobs])

    pool.start()
    try:
        await asyncio.wait_for(queue.join(), timeout=5)
    finally:
        await pool.stop(timeout=2)

    assert checker.peak == 4


async def test_single_worker_runs_sequentially(service: JobService):
    queue = JobQueue()
    checker = StubChecker(delay=0.01)
    pool = WorkerPool(queue, service, checker, worker_count=1)
    _, jobs = await service.create_batch([f"https://{i}.test/" for i in range(4)])
    queue.enqueue_many([job.id for job in jobs])

    pool.start()
    try:
        await asyncio.wait_for(queue.join(), timeout=5)
    finally:
        await pool.stop(timeout=2)

    assert checker.peak == 1


async def test_worker_survives_checker_exception(service: JobService):
    queue = JobQueue()
    pool = WorkerPool(queue, service, ExplodingChecker(), worker_count=1)
    batch, jobs = await service.create_batch(["https://boom.test/", "https://fine.test/"])
    queue.enqueue_many([job.id for job in jobs])

    pool.start()
    try:
        await asyncio.wait_for(queue.join(), timeout=5)
        assert pool.running_workers == 1
    finally:
        await pool.stop(timeout=2)

    boom = await service.get_job(jobs[0].id)
    assert boom.status is JobStatus.FAILED
    assert "kaboom" in boom.result.error_message
    assert (await service.get_job(jobs[1].id)).status is JobStatus.COMPLETED
    assert await batch_status(service, batch.id) is JobStatus.PARTIALLY_FAILED


async def test_already_finished_job_is_skipped(service: JobService):
    queue = JobQueue()
    checker = StubChecker()
    pool = WorkerPool(queue, service, checker, worker_count=1)
    job = await service.create_job("https://once.test/")
    queue.enqueue_many([job.id, job.id])

    pool.start()
    try:
        await asyncio.wait_for(queue.join(), timeout=5)
    finally:
        await pool.stop(timeout=2)

    assert checker.seen == ["https://once.test/"]


async def test_job_is_running_while_being_checked(service: JobService):
    queue = JobQueue()
    checker = BlockingChecker()
    pool = WorkerPool(queue, service, checker, worker_count=1)
    job = await service.create_job("https://slow.test/")
    queue.enqueue(job.id)

    pool.start()
    try:
        await asyncio.wait_for(checker.started.wait(), timeout=2)
        assert (await service.get_job(job.id)).status is JobStatus.RUNNING
        assert pool.busy_workers == 1
        checker.release.set()
        await asyncio.wait_for(queue.join(), timeout=2)
    finally:
        await pool.stop(timeout=2)

    assert (await service.get_job(job.id)).status is JobStatus.COMPLETED


async def test_graceful_shutdown_finishes_in_flight_job_and_keeps_rest_pending(
    service: JobService,
):
    queue = JobQueue()
    checker = StubChecker(delay=0.2)
    pool = WorkerPool(queue, service, checker, worker_count=1)
    _, jobs = await service.create_batch([f"https://{i}.test/" for i in range(3)])
    queue.enqueue_many([job.id for job in jobs])

    pool.start()
    await asyncio.wait_for(checker.started.wait(), timeout=2)
    await pool.stop(timeout=5)

    statuses = [(await service.get_job(job.id)).status for job in jobs]
    assert statuses == [JobStatus.COMPLETED, JobStatus.PENDING, JobStatus.PENDING]
    assert queue.size == 2
    assert pool.running_workers == 0


async def test_forced_shutdown_returns_interrupted_job_to_pending(service: JobService):
    queue = JobQueue()
    checker = BlockingChecker()
    pool = WorkerPool(queue, service, checker, worker_count=1)
    job = await service.create_job("https://hang.test/")
    queue.enqueue(job.id)

    pool.start()
    await asyncio.wait_for(checker.started.wait(), timeout=2)
    await pool.stop(timeout=0.05)

    assert (await service.get_job(job.id)).status is JobStatus.PENDING
    assert pool.running_workers == 0


async def test_stopping_idle_workers_is_quick(service: JobService):
    pool = WorkerPool(JobQueue(), service, StubChecker(), worker_count=5)
    pool.start()
    await wait_until(lambda: pool.running_workers == 5)

    await asyncio.wait_for(pool.stop(timeout=10), timeout=1)

    assert pool.running_workers == 0


async def test_pool_cannot_be_started_twice_and_can_restart(service: JobService):
    queue = JobQueue()
    pool = WorkerPool(queue, service, StubChecker(), worker_count=1)
    pool.start()
    try:
        try:
            pool.start()
        except RuntimeError:
            pass
        else:
            raise AssertionError("Expected RuntimeError")
    finally:
        await pool.stop(timeout=1)

    job = await service.create_job("https://again.test/")
    queue.enqueue(job.id)
    pool.start()
    try:
        await asyncio.wait_for(queue.join(), timeout=2)
    finally:
        await pool.stop(timeout=1)
    assert (await service.get_job(job.id)).status is JobStatus.COMPLETED
