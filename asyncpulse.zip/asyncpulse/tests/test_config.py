import pytest
from pydantic import ValidationError

from app.core.config import Settings


def test_defaults(monkeypatch):
    for name in ("WORKER_COUNT", "MAX_CONCURRENCY", "MAX_RETRIES"):
        monkeypatch.delenv(f"ASYNCPULSE_{name}", raising=False)

    settings = Settings(_env_file=None)

    assert settings.worker_count == 4
    assert settings.max_concurrency == 10
    assert settings.max_retries == 3
    assert settings.database_url.startswith("sqlite+aiosqlite")


def test_environment_overrides(monkeypatch):
    monkeypatch.setenv("ASYNCPULSE_WORKER_COUNT", "7")
    monkeypatch.setenv("ASYNCPULSE_REQUEST_TIMEOUT", "2.5")

    settings = Settings(_env_file=None)

    assert settings.worker_count == 7
    assert settings.request_timeout == 2.5


def test_env_file_is_loaded(tmp_path):
    env_file = tmp_path / ".env"
    env_file.write_text("ASYNCPULSE_MAX_CONCURRENCY=3\nASYNCPULSE_MAX_RETRIES=0\n")

    settings = Settings(_env_file=env_file)

    assert settings.max_concurrency == 3
    assert settings.max_retries == 0


@pytest.mark.parametrize(
    "overrides",
    [{"worker_count": 0}, {"max_concurrency": 0}, {"request_timeout": 0}, {"max_retries": -1}],
)
def test_invalid_values_are_rejected(overrides):
    with pytest.raises(ValidationError):
        Settings(_env_file=None, **overrides)
