import pytest

from app.db.models import JobStatus
from app.db.session import Database
from app.services.jobs import JobService, derive_batch_status
from app.services.monitor import CheckOutcome

P, R, C, F = (
    JobStatus.PENDING,
    JobStatus.RUNNING,
    JobStatus.COMPLETED,
    JobStatus.FAILED,
)


def outcome(url: str, success: bool = True) -> CheckOutcome:
    if success:
        return CheckOutcome(url, True, 200, 12.5, None, 1)
    return CheckOutcome(url, False, 503, 30.0, "HTTP 503", 3)


@pytest.mark.parametrize(
    ("counts", "expected"),
    [
        ({}, JobStatus.PENDING),
        ({P: 3}, JobStatus.PENDING),
        ({P: 1, R: 1}, JobStatus.RUNNING),
        ({R: 3}, JobStatus.RUNNING),
        ({P: 2, C: 1}, JobStatus.RUNNING),
        ({P: 1, F: 2}, JobStatus.RUNNING),
        ({C: 3}, JobStatus.COMPLETED),
        ({F: 3}, JobStatus.FAILED),
        ({C: 2, F: 1}, JobStatus.PARTIALLY_FAILED),
        ({C: 1, F: 1}, JobStatus.PARTIALLY_FAILED),
    ],
)
def test_derive_batch_status(counts, expected):
    assert derive_batch_status(counts) is expected


async def test_single_job_lifecycle(service: JobService):
    job = await service.create_job("https://example.com/")
    assert job.status is JobStatus.PENDING
    assert job.batch_id is None

    assert await service.claim_job(job.id) == "https://example.com/"
    assert (await service.get_job(job.id)).status is JobStatus.RUNNING

    await service.record_result(job.id, outcome("https://example.com/"))
    stored = await service.get_job(job.id)
    assert stored.status is JobStatus.COMPLETED
    assert stored.result.status_code == 200
    assert stored.result.response_time_ms == 12.5
    assert stored.result.attempts == 1
    assert stored.result.success is True


async def test_failed_result_marks_job_failed(service: JobService):
    job = await service.create_job("https://example.com/")
    await service.claim_job(job.id)
    await service.record_result(job.id, outcome("https://example.com/", success=False))

    stored = await service.get_job(job.id)
    assert stored.status is JobStatus.FAILED
    assert stored.result.error_message == "HTTP 503"
    assert stored.result.attempts == 3


async def test_claim_only_succeeds_for_pending_jobs(service: JobService):
    job = await service.create_job("https://example.com/")

    assert await service.claim_job(job.id) is not None
    assert await service.claim_job(job.id) is None
    assert await service.claim_job("missing") is None


async def test_release_returns_running_job_to_pending(service: JobService):
    job = await service.create_job("https://example.com/")
    await service.claim_job(job.id)

    await service.release_job(job.id)

    assert (await service.get_job(job.id)).status is JobStatus.PENDING


async def test_unknown_job_and_batch_return_none(service: JobService):
    assert await service.get_job("nope") is None
    assert await service.get_batch("nope") is None
    assert await service.get_batch_results("nope") is None


async def test_batch_status_transitions_to_completed(service: JobService):
    batch, jobs = await service.create_batch(["https://a.test/", "https://b.test/"])
    assert (await service.get_batch(batch.id)).status is JobStatus.PENDING

    await service.claim_job(jobs[0].id)
    assert (await service.get_batch(batch.id)).status is JobStatus.RUNNING

    await service.record_result(jobs[0].id, outcome(jobs[0].url))
    summary = await service.get_batch(batch.id)
    assert summary.status is JobStatus.RUNNING
    assert summary.counts == {C: 1, P: 1}

    await service.claim_job(jobs[1].id)
    await service.record_result(jobs[1].id, outcome(jobs[1].url))
    summary = await service.get_batch(batch.id)
    assert summary.status is JobStatus.COMPLETED
    assert summary.total == 2


async def test_batch_status_partially_failed(service: JobService):
    batch, jobs = await service.create_batch(["https://a.test/", "https://b.test/"])
    for job, success in zip(jobs, [True, False]):
        await service.claim_job(job.id)
        await service.record_result(job.id, outcome(job.url, success))

    summary = await service.get_batch(batch.id)
    assert summary.status is JobStatus.PARTIALLY_FAILED
    assert summary.counts == {C: 1, F: 1}


async def test_batch_status_failed(service: JobService):
    batch, jobs = await service.create_batch(["https://a.test/", "https://b.test/"])
    for job in jobs:
        await service.claim_job(job.id)
        await service.record_result(job.id, outcome(job.url, success=False))

    assert (await service.get_batch(batch.id)).status is JobStatus.FAILED


async def test_batch_results_only_include_finished_checks(service: JobService):
    batch, jobs = await service.create_batch(["https://a.test/", "https://b.test/"])
    await service.claim_job(jobs[0].id)
    await service.record_result(jobs[0].id, outcome(jobs[0].url))

    summary, results = await service.get_batch_results(batch.id)

    assert summary.status is JobStatus.RUNNING
    assert [result.job_id for result in results] == [jobs[0].id]


async def test_batch_jobs_do_not_leak_between_batches(service: JobService):
    first, first_jobs = await service.create_batch(["https://a.test/"])
    second, _ = await service.create_batch(["https://b.test/", "https://c.test/"])

    assert (await service.get_batch(first.id)).total == 1
    assert (await service.get_batch(second.id)).total == 2
    assert first_jobs[0].batch_id == first.id


async def test_discard_removes_jobs_and_batch(service: JobService):
    batch, jobs = await service.create_batch(["https://a.test/", "https://b.test/"])

    await service.discard_jobs([job.id for job in jobs], batch.id)

    assert await service.get_batch(batch.id) is None
    assert await service.get_job(jobs[0].id) is None


async def test_recover_unfinished_resets_running_and_lists_pending(service: JobService):
    done = await service.create_job("https://done.test/")
    await service.claim_job(done.id)
    await service.record_result(done.id, outcome(done.url))
    running = await service.create_job("https://running.test/")
    await service.claim_job(running.id)
    pending = await service.create_job("https://pending.test/")

    recovered = await service.recover_unfinished()

    assert set(recovered) == {running.id, pending.id}
    assert (await service.get_job(running.id)).status is JobStatus.PENDING
    assert (await service.get_job(done.id)).status is JobStatus.COMPLETED


async def test_data_survives_restart(settings):
    first = Database(settings.database_url)
    await first.create_all()
    first_service = JobService(first.session_factory)
    batch, jobs = await first_service.create_batch(["https://a.test/", "https://b.test/"])
    await first_service.claim_job(jobs[0].id)
    await first_service.record_result(jobs[0].id, outcome(jobs[0].url))
    await first.dispose()

    second = Database(settings.database_url)
    await second.create_all()
    second_service = JobService(second.session_factory)
    try:
        summary, results = await second_service.get_batch_results(batch.id)
        assert summary.total == 2
        assert summary.status is JobStatus.RUNNING
        assert len(results) == 1
        assert results[0].url == "https://a.test/"
        assert results[0].checked_at.tzinfo is not None
        assert (await second_service.get_job(jobs[1].id)).status is JobStatus.PENDING
    finally:
        await second.dispose()
